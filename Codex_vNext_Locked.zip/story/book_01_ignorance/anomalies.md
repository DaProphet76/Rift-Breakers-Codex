# Anomalies (Book 01)

This file tracks strange events that characters observe but cannot explain.

Template per anomaly:
- Date/Chapter:
- What happened (POV description):
- Why it is strange (from character view):
- Canon explanation link (world_bible file):
