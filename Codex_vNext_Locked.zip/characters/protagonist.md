# Protagonist (Dossier)

## Role
- “The One” (convergence point), first to regain access
- Begins cut off from True Code; can follow Written Code

## Starting State
- spiritually dormant
- high discipline potential
- guided by written law, not by power

## Arc (Non-Prose)
- awakens partial access
- unlocks abilities through growth
- never achieves total mastery of the Code
- leads other chosen toward alignment

## Notes
- Name TBD
- Origin TBD
