# Chapter 00
The world remembers.
The story begins.

They tell us the world ended once.

Not all at once.
But in fire and stone, when the sky fell and left a wound so deep the land never healed.

There is still a place where nothing grows.
A vast scar in the realm where storms bend away and life forgets how to return.

That was the Sundering Fall.

They say the survivors rebuilt.
That eight great families rose from the ruin and carried the world forward.

Seven to rule.
One to serve.

They taught us this was order.

After the wars came the rifts.
Cracks in the world that bled monsters into our streets.

So we retreated inward.
District by district. Ring by ring.

The inner cities grew bright and guarded.
The outer rings learned to listen for screams and measure nights by survival.

Then came the dig.

When they unearthed the artifact, the world shuddered—
and the Resonance rolled outward like a memory remembered by the blood.

An Echo settled into us.

Some awakened.
Not kings. Not lords.
People from streets like mine.

Demons learned they could die.

They call those people heroes now.
Train them. Brand them.

I was born after the Resonance.
In the outer districts.
Where history teaches obedience—and hope learns to hide.

This is the world as we were taught it.

And this…
is where the story begins.
