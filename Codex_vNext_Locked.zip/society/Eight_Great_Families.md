# The Eight Great Families

Modern civilization is structured around eight ancestral families.

## The Seven High Families
These families compete for influence, governance, and legitimacy.

- House Valenor — Law and civil order
- House Kethryn — Military authority
- House Aurel — Commerce and central governance
- House Solmyr — Knowledge and sanctioned history
- House Dravain — Infrastructure and district planning
- House Elyndor — Culture and media
- House Marric — Moral and civic doctrine

## The Lesser Family

The eighth family is regarded as fractured and diminished.

It is believed to consist of twelve branches descended from a single failed lineage.

In truth, the branches do not share the same root seed.

Slavery tied to this family has been abolished, but social stigma and systemic exclusion persist.
