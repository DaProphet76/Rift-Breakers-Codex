# The Scar

The Scar is a massive cratered region formed during the Sundering Fall.

Life within the Scar is sparse or twisted. Flora fails to take root. Fauna is rare and often altered. Weather patterns behave erratically around its borders.

The Scar is considered taboo. It is avoided by settlers and heavily restricted by ruling authorities.

Official doctrine teaches that the Scar is proof of the world's fragility and a warning against hubris.
