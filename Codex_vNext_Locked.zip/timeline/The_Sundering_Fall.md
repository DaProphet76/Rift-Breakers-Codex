# The Sundering Fall

The Sundering Fall marks the end of the First Age and the beginning of recorded history.

It was a cataclysm of fire, stone, and upheaval. Cities were shattered, seas displaced, and the land itself was wounded.

At the heart of the destruction lies a vast cratered deadland, known commonly as **the Scar**. Little lives there. Storms bend around it. Expeditions rarely return unchanged.

In later centuries, the Sundering would be framed as judgment, disaster, or consequence—depending on the authority recounting it.

What is agreed upon is this: the world that existed before did not survive.
