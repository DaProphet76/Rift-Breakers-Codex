# The Resonance

The Resonance refers to the planetary surge released during the archaeological excavation event.

When the artifact was unearthed, an energetic wave propagated across the realm.

This wave left an **Echo** within human DNA, unlocking dormant abilities in a subset of the population.

The Awakening was random and unpredictable, affecting individuals across all districts.

Public institutions frame the Resonance as a miracle. Its true nature remains undefined.
