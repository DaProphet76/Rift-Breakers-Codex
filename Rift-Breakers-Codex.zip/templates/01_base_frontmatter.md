---
title: "<TITLE>"
type: "<TYPE>"  # realm | tenet | artifact | character | event | location | faction | creature | system | timeline | scene | note
status: "draft" # draft | canon | revised | deprecated
version: "0.1"
last_updated: "2025-12-26"
author: "Yoshua Israel"
source: "Codex"
related_entries:
  - "<PATH_OR_SLUG>"
tags:
  - "<TAG>"
---

# <TITLE>

## Summary
<2–5 sentences. What this entry is, and why it matters.>

## Canon Notes
- **What is confirmed:** <bullet list>
- **What is intentionally unknown:** <bullet list>
- **Open questions:** <bullet list>

## References
- <Links to other Codex entries>
