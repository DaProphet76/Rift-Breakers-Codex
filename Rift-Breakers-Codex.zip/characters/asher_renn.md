---
title: "Asher Renn"
type: "character"
status: "canon"
version: "1.0"
last_updated: "2025-12-28"
author: "Yoshua Israel"
source: "Codex"
related_entries:
- mara
- kellan
tags:
- character
- supporting_lead
- witness
---

## Quick Identity
- **Full Name:** Asher Renn
- **Origin / District:** Outer Ring
- **Role in Story:** Supporting lead; narrative bridge to the true hero

## Appearance
Lean, work-worn, easily overlooked.

## Personality
Observant, steady, cautious.

## Background
Raised in the outer ring under constant surveillance.

## Arc
Observer → catalyst → ally.

## Canon Notes
- **Not the primary hero**
- Feels a persistent pull

## References
- chapter_01
