# The First Artifact

The artifact originates from the portion of the realm removed during the Catalyst.
It is composed of material unknown to the realm and may be technological in nature.

Upon excavation, it emitted a realm-wide energy broadcast that awakened
latent Code resonance across the population and into space.

After the broadcast, it became inert until bonding with the One.
When bonded, it affixes to the left wrist and functions as a Code seal,
providing a HUD-like interface governed by progression.