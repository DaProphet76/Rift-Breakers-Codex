# The Written Code

The Code was translated into written laws.
These laws guide civilization but do not grant power.