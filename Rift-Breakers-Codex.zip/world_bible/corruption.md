# Corruption

Misalignment with the Code weakens the soul.
Early awakening without strengthening leaves the soul open
to corruption, possession, or destruction.