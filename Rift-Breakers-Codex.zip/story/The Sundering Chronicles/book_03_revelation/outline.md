# Book 03 — Revelation (Outline)

Goal: the true history of the Tear becomes undeniable.

Key beats (high level):
- origin knowledge surfaces
- the hero’s limitations are tested
- final confrontation involves Code alignment vs corruption
