# Book 02 — Disruption (Outline)

Goal: the veil weakens. factions form around partial truths and counterfeit access.

Key beats (high level):
- chosen individuals emerge
- forced-access methods spread
- spiritual consequences intensify
