---
title: "<LOCATION NAME>"
type: "location"
status: "draft"
version: "0.1"
last_updated: "2025-12-26"
author: "Yoshua Israel"
source: "Codex"
related_entries:
  - "world_bible/realms/<REALM>.md"
tags:
  - "location"
  - "<REGION>"
---

# <LOCATION NAME>

## Summary
<2–5 sentences.>

## Geography
- **Terrain:** 
- **Climate:** 
- **Natural hazards:** 

## Culture
- **Dominant peoples:** 
- **Customs:** 
- **Taboos:** 

## Governance
- **Rulers:** 
- **Laws:** 
- **Conflicts:** 

## Economy and Resources
- **Key resources:** 
- **Trade routes:** 

## Points of Interest
- <site>
- <site>

## Secrets (Optional)
<Hidden truths, ancient ruins, spiritual bleed-through, etc.>

## Narrative Use
<How and when this location appears in the story.>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:>

## References
- <links>
