---
title: "<CREATURE/ENTITY NAME>"
type: "creature"
status: "draft"
version: "0.1"
last_updated: "2025-12-26"
author: "Yoshua Israel"
source: "Codex"
related_entries:
  - "world_bible/realms/<REALM>.md"
tags:
  - "creature"
  - "entity"
---

# <CREATURE/ENTITY NAME>

## Summary
<2–5 sentences.>

## Classification
- **Type:** <beast, spirit, construct, hybrid>
- **Realm of origin:** 

## Description
- <appearance and behavior>

## Intelligence and Communication
- <sentience level, language, signs>

## Abilities
- <ability>
- <ability>

## Weaknesses / Limitations
- <weakness>

## Ecology / Role in World
<Where it fits in the setting.>

## Encounters
- <known event/encounter>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>
