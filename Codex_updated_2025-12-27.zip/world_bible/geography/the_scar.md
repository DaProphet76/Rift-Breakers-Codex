# The Scar

The Scar is a massive deadland crater formed during the Sundering Fall.

Life fails to thrive. Expeditions rarely return unchanged.
It is a place of taboo and warning.
