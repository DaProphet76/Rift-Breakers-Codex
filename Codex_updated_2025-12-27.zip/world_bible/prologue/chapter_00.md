# Chapter 00

They tell us the world ended once.

There is still a place where nothing grows.
A scar where the land never healed.

After the rifts came the Resonance.
An Echo in the blood.

I was born after it.
This is where the story begins.
