# The Sundering Fall

The Sundering Fall marks the end of the First Age.

It shattered cities, displaced seas, and left a vast cratered deadland known as **the Scar**.
Little lives there. Storms bend around it.

The world that existed before did not survive.
