# The Eight Great Families

Civilization is structured around eight ancestral families.

## Seven High Families
- Valenor — Law
- Kethryn — Military
- Aurel — Commerce and rule
- Solmyr — Knowledge
- Dravain — Infrastructure
- Elyndor — Culture
- Marric — Civic doctrine

## The Lesser Family
Believed to be one family with twelve branches.

They do not share the same root seed.

Slavery is abolished. Disdain is not.
