# The Resonance

The Resonance was released when an ancient artifact was unearthed.

It left an **Echo** within human DNA, awakening latent abilities.
