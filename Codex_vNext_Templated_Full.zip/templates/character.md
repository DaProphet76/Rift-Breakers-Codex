---
title: "<CHARACTER NAME>"
type: "character"
status: "draft"
version: "0.1"
last_updated: "2025-12-26"
author: "Yoshua Israel"
source: "Codex"
related_entries:
  - "world_bible/tenets/<TENET>.md"
  - "world_bible/artifacts/<ARTIFACT>.md"
tags:
  - "character"
  - "<FACTION>"
---

# <CHARACTER NAME>

## Summary
<2–5 sentences. Who they are and their role.>

## Identity
- **Names / aliases:** 
- **Titles:** 
- **Age / era:** 
- **Origin:** <place + realm>

## Appearance
- <key traits only>

## Personality and Psychology
- **Motivations:** 
- **Fears:** 
- **Flaws:** 
- **Virtues:** 

## Capabilities
- **Training/skills:** 
- **Powers/awakenings:** 
- **Gear/artifacts:** 

## Awareness Level
- Physical-only | Spirit-aware | Dual-realm operative | Unknown

## Relationships
- **Allies:** 
- **Rivals:** 
- **Mentors:** 
- **Dependents:** 

## Backstory
<Pre-story history that shapes them.>

## Narrative Arc
- **Start state:** 
- **Key turning points (planned):**
- **End state (planned):**

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>
