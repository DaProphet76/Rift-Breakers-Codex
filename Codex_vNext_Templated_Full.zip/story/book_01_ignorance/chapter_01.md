# Chapter 01 (Draft Placeholder)

Write in POV.
Do not explain canon rules directly.
Show effects and confusion.
