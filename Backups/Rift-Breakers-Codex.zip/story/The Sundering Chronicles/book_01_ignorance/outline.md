# Book 01 — Ignorance (Outline)

Goal: establish a world where the spiritual realm is hidden and the written laws are treated as history, culture, or religion.

Key beats (high level):
- The hero lives by written law but lacks True Code access.
- Early anomalies hint that “cause and consequence” behaves strangely.
- A triggering event begins partial awakening.
