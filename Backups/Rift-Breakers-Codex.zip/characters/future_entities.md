# Future Entities (Dossier)

Placeholder for:
- key spiritual beings
- ancient custodians
- future antagonists
- realm-specific agents
