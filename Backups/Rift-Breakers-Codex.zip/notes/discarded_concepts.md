# Discarded Concepts (Non-Canon)

Store anything you want to keep without committing to canon.
Safe to contradict everything else.
