---
title: "Cosmology"
type: "world_bible_entry"
status: "canon"
---

# Cosmology

The Maker exists outside time and space.
Through the Code, all realms were created.
Harmony existed until sin entered the first realm.