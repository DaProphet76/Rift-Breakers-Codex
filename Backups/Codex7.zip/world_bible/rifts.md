---
title: "Rifts"
type: "world_bible_entry"
status: "canon"
---

# Rifts

Rifts are micro-tears caused by accumulated sin.
If left unclosed, they allow population-level possession.
Rifts have not yet begun to form in the current age.