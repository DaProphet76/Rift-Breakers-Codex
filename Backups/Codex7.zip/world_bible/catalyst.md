---
title: "Catalyst"
type: "world_bible_entry"
status: "canon"
---

# The Catalyst (The Cataclyst)

When sin reached a critical threshold, the Maker caused a Tear.
A portion of the realm was removed, leaving a massive crater.
The Maker then withdrew from direct influence.