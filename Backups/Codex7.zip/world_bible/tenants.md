---
title: "Tenants"
type: "world_bible_entry"
status: "canon"
---

# The Written Code

The Code was translated into written laws.
These laws guide civilization but do not grant power.