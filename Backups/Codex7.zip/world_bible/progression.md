---
title: "Progression"
type: "world_bible_entry"
status: "canon"
---

# Progression

Awakening occurs in stages.
Partial synchronization precedes strengthening.
Full Sync is restricted to a single individual.