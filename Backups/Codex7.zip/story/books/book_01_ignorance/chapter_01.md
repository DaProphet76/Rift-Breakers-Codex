---
title: "Chapter 01"
type: "chapter"
status: "draft"
---

# Chapter 01

## Batch 01
Morning came late to the outer districts.

Not because the sun delayed—only because the light had farther to travel, slipping past towers and shield-plates, losing strength as it went. By the time it reached the streets at the edge of the city, it was thin and colorless, more suggestion than warmth.

The boy woke to sirens.

They were not the kind that signaled attack. Those were sharper, urgent, meant to drive people indoors. These were slower, rhythmic—work-call tones that rolled across the outer ring like a tired breath, reminding everyone that the day had begun whether they were ready for it or not.

He lay still for a moment, listening.

Metal creaked somewhere above. A neighbor coughed through the wall—deep, wet, familiar. Far off, something boomed as a gate shifted position along the inner barricade. The sound traveled outward, losing authority with every echo until it reached this place as a dull thud, like a distant door being closed on someone else’s life.

He sat up.

The room was small. Everything was small out here. Low ceiling. Narrow cot. A single slit-window reinforced with wire and etched glass that dulled the view beyond it into a blur of gray shapes. The walls bore old cracks that had been sealed and resealed so many times they looked like scars layered atop scars.

He pulled on his boots and stood.

Outside, the street was already moving. People flowed past one another without greeting, heads down, shoulders tight. Couriers in patched jackets ran messages toward the inner ring. Vendors shouted half-hearted offers that no one answered. Overhead, the shield lattice hummed faintly—a sound everyone noticed only when it stopped.

Posters clung to the wall across the street.

Fresh ones had been layered over older notices, their edges curling in the morning chill. Faces stared out in stylized colors: young men and women caught mid-motion, hands raised, eyes bright with promise. Below each face, a crest. Below each crest, a sponsor mark.

AWAKENED INSTITUTE — SECOND RING
Applications Open

He looked away.

Everyone knew someone who had applied. Everyone knew someone who hadn’t come back.

A pair of city enforcers passed at the end of the street, armor clean, movements precise. Their insignia marked them as inner-ring assigned—House Aurel by the cut of the sigil alone. They did not look toward the buildings. They never did. Their presence was a reminder, not a service.

“Did you hear?”

The voice came from his left. Old Mara, leaning in her doorway, shawl wrapped tight. She had lived in this building longer than anyone remembered, which meant she had survived things most people only whispered about.

“Another rift last night,” she said without waiting for a reply. “Far east. Fourth ring. Took a whole block.”

He nodded. That was the proper response. Shock was for people who could afford it.

“They say an Awakened closed it,” she added, eyes sharp now. “One of the new ones. Sponsored.”

“Good,” he said.

She snorted softly. “Good for who?”

The sirens changed tone—shift-call now. The day pushed forward.

He joined the flow toward the work corridors, boots striking worn stone. As he walked, he felt it again—that faint pressure behind his eyes. Not pain. Not quite. A hum, barely there, like standing too close to something powerful and pretending not to notice.

He clenched his jaw and kept moving.

Somewhere in the city, far closer to the center than this place would ever be, banners were being raised. Contracts signed. Training halls opened their doors.

Heroes were being made.

And out here, in the outer ring, the walls remembered everything they were built to keep out.

The boy did not know why the hum followed him.

Only that it had begun three nights ago.

And that it had not stopped.

## Batch 02
The work corridors ran beneath the outer ring like roots that had learned to live without light.

They were straight where they could be straight, bent where the city had grown tired of pretending to care. The walls bore old numbering that no longer matched any map, and the lights hummed with the thin persistence of something that knew it would never be repaired—only replaced when it failed loudly enough.

The boy joined the morning line at Checkpoint Nine.

The corridor narrowed there, forcing people into closeness. Elbows brushed. Breath mixed. No one apologized.

“Hands out,” the guard said, voice flat with repetition. “Palms up. Don’t make me ask twice.”

The boy lifted his hands. He kept his gaze on the guard’s chin—not the eyes. Looking into the eyes invited questions. Questions invited delays.

Behind him, a man muttered, “They added another scanner.”

A woman answered quietly, “They always add another scanner. That’s how you know nothing’s changed.”

The man snorted. “Feels like it’s changing.”

“It isn’t,” she said. “It just wants you to think it is.”

The guard’s slate chimed. Green light.

“Move.”

They moved.

Past the checkpoint, the corridor opened into the market spine, and the crowd loosened like a held breath released. Stalls pressed close to the walls—patched awnings, bent frames, goods stacked in careful scarcity. The smells layered over one another: hot oil, boiled greens, metal dust, and the faint bitterness of recycled water.

A vendor called out, “Fresh bread! Fresh today!”  
No one corrected her. Fresh meant edible.

The boy slowed as screens flickered overhead.

CURFEW REMAINS IN EFFECT  
REPORT SUSPICIOUS ACTIVITY  
RESIDENCE VERIFICATION REQUIRED FOR SECOND-RING ENTRY

Then the notices shifted.

Faces appeared—bright, polished, impossibly clean. Young men and women caught mid-gesture, framed as if the world itself leaned toward them.

GET TESTED. GET SEEN. GET OUT.

Kellan was waiting near the work bay, chewing on a ration-stick like it offended him.

“You look thoughtful,” Kellan said. “That’s dangerous before a shift.”

“I was thinking,” the boy replied, “that they’ve started smiling wider on the posters.”

Kellan glanced up. “That’s because they’re selling hope again.”

“Does anyone buy it?”

“Enough do.”

They entered the bay together. The crew stood in loose clusters, murmuring about assignments and shortages.

Supervisor Den arrived with his slate tucked under one arm, jacket still clean enough to reflect the light.

“Quiet,” Den said.

The room obeyed.

“We’re behind,” Den continued. “Which means someone here is not pulling their weight.”

No one spoke.

“You,” Den said, pointing. “Conduit line six. Lift near corridor C is stalling again.”

The boy nodded.

“If it stalls after you touch it,” Den added, “I don’t want excuses.”

Corridor C was crowded. The lift platform sat idle.

“Before you say anything,” the operator said, “I didn’t break it.”

“No one said you did,” the boy replied.

“They docked my ration last time.”

“We’ll fix it,” Kellan said.

“You always say that.”

“And yet you’re still here.”

They worked slowly. Carefully.

Nearby, teenagers clustered beneath a sponsor screen.

“My cousin went for testing,” one said.

“When?”

“Last month.”

“And?”

“Nothing.”

Kellan shook his head. “They’re still telling that story.”

“What story?”

“That testing is a ladder.”

“And it isn’t?”

“Ladders have rungs that break.”

The lift rose smoothly.

The operator exhaled. “Good.”

By the end of shift, Den nodded once.

“Tomorrow,” he said, “shield-lattice sweep.”

On the return walk, the screens still cycled.

GET TESTED. GET SEEN. GET OUT.

The boy stopped beneath one.

This isn’t how life is supposed to be, he thought.

At the stairwell, he paused.

Testing.

Some never returned. Some returned wrong.

No successful stabilization has ever been recorded.  
All known cases end in death or demonic possession.

He climbed the stairs.

Not choosing.

But no longer pretending the choice didn’t exist.

## Batch 03
Walls close.
Order asserts itself.

The lockdown siren did not scream.

That was how the boy knew it was real.

The scream-sirens were for rifts, for monsters, for things the districts could point at and name. This one was lower, steadier—a sound meant to settle into the bones and stay there. It rolled through the outer ring in measured pulses, neither hurried nor apologetic.

Lockdown tone.

The market spine froze.

People did not run. Running was for alarms that might be mistakes. This one carried the weight of procedure. Stalls were abandoned mid-pack. A cart tipped as its owner let go of the handle. Somewhere, a child began to cry and was silenced quickly, a hand clapped over a mouth with practiced urgency.

The boy stopped where he stood.

Above, the shield lattice brightened—not fully, not the way it did during a breach, but enough that the air took on a faint metallic taste. Lights shifted from white to amber.

REMAIN WHERE YOU ARE
AWAIT INSTRUCTIONS

The words scrolled across the screens in calm, official lettering.

Kellan appeared at his side as if summoned by the sound.

“Tell me this isn’t about us,” Kellan said quietly.

“If it were,” the boy replied, “they’d already be shouting.”

That was when the inner-ring units arrived.

They did not rush. They never rushed. Their armor was smooth, unscuffed, marked with crests that caught the amber light and reflected it back cleanly. House Aurel’s sigil was visible on two of them; another bore markings the boy didn’t recognize but understood instinctively meant not outer ring.

People stepped back without being told.

An officer raised a hand. Not a weapon. A hand.

“Remain calm,” she said. “This is a routine containment sweep. There is no threat.”

No threat you are allowed to understand, the boy thought.

The officer’s eyes moved across the crowd—not counting, but categorizing.

A man near the bread stall shifted his weight.

“Sir,” the officer said, without turning her head. “Do not move.”

The man froze.

Two enforcers peeled away from the line and approached him. They asked questions quietly. The man answered too quickly. Then too slowly.

A scanner hummed.

Red.

The enforcers took his arms.

His wife stepped forward. “Please. He didn’t do anything. We’ve been here twenty years—”

“Ma’am,” the officer said. “Step back.”

She didn’t.

An enforcer placed a hand on her shoulder and guided her back, gently, firmly.

The man was led away.

Not dragged. Led.

Kellan swallowed. “What are they scanning for?”

“Something they don’t like,” the boy said.

They moved on.

Faces scanned. Slates checked. A teenager was taken. Then an older man.

No one fought.

Fighting was for stories.

When the officer reached the boy and Kellan, the scanner passed over them.

Green.

The officer moved on.

The boy realized his hands were clenched.

The lockdown lifted.

RESUME ACTIVITY
THANK YOU FOR YOUR COOPERATION

The crowd did not resume anything right away.

People stared after those taken.

The bread stall stood empty.

“Routine,” Kellan said. “That’s what they call it.”

The boy nodded.

Routine meant it would happen again.

That night, the district felt smaller.

From his window, the inner ring glowed warm and untouched.

The boy thought of the man led away. Of the woman who would not sell bread tomorrow.

This is how it works, he realized.

Not with monsters.

With lists.

He sat on his cot and stared at his hands.

Testing.

A room with clean floors. White lights. A slate deciding whether you mattered.

He understood why people went.

Not to be heroes.

But to stop being replaceable.

The city settled.

The boy lay down without undressing.

He did not sleep.

The question he carried was no longer distant.

It was close.

And waiting.
