---
title: "TEMPLATE_REFERENCE"
type: "template_reference"
status: "canon"
version: "2.0"
last_updated: "2025-12-28"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
  - templates
  - reference
  - canon
---

# TEMPLATE_REFERENCE

## Purpose (READ FIRST)
This file is the **single source of truth** for all Markdown files in the Codex.

Rule:
- Every file starts with the Universal Frontmatter
- The `type:` field selects which body template to use
- Copy the matching section below, paste it into the file, and fill it in
- No other template files are required

---

## Universal Frontmatter (REQUIRED FOR ALL FILES)

```md
---
title: "<TITLE>"
type: "<TYPE>"
status: "draft"
version: "0.1"
last_updated: "YYYY-MM-DD"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
  - tag1
  - tag2
---
```

---

## Template: Scene / Chapter (`type: scene`)

```md
# <SCENE / CHAPTER TITLE>

## Purpose
...

## Viewpoint
- **POV character:** ...
- **POV limitations:** ...

## Setting
- **Location:** ...
- **Time:** ...
- **Atmosphere:** ...

## Scene Beats
1. ...

## Conflict
- **External:** ...
- **Internal:** ...

## Reveal / Information Drop
...

## Outcome
...

## Hooks
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Timeline Entry (`type: timeline`)

```md
# <TIMELINE ENTRY TITLE>

## Date / Era
...

## Summary
...

## Details
- ...

## Sources of Truth
- **Primary:** ...
- **Secondary:** ...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: System / Magic / Anomaly (`type: system`)

```md
# <SYSTEM NAME>

## Summary
...

## Scope
- **Applies to:** ...
- **Observed by:** ...

## Core Rules
1. ...

## Inputs and Outputs
- **Inputs:** ...
- **Outputs:** ...

## Failure Modes
...

## Known Instances
...

## Narrative Purpose
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Realm (`type: realm`)

```md
# <REALM NAME>

## Summary
...

## Origin
...

## Governing Laws
...

## Interfaces With Other Realms
...

## Inhabitants
...

## Narrative Purpose
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Character (`type: character`)

```md
# <CHARACTER NAME>

## Summary
...

## Identity
...

## Personality
...

## Capabilities
...

## Narrative Arc
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Artifact (`type: artifact`)

```md
# <ARTIFACT NAME>

## Summary
...

## Description
...

## Origin
...

## Abilities
...

## Limitations
...

## Narrative Role
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Location (`type: location`)

```md
# <LOCATION NAME>

## Summary
...

## Geography
...

## Culture
...

## Governance
...

## Narrative Use
...

## Canon Notes
- **Confirmed:**
- **Intentionally unknown:**
- **Open questions:**

## References
- ...
```
---

## Template: Note (`type: note`)

```md
# <NOTE TITLE>

## Purpose
...

## Content
...

## Next Actions
...
```
---

## Legacy Types (DO NOT USE)
- scene_chapter → scene
- timeline_entry → timeline
- system_magic_or_anomaly → system
- chapter → scene + tag chapter
