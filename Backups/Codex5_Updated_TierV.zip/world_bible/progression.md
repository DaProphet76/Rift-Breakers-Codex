# Progression

Awakening occurs in stages.
Partial synchronization precedes strengthening.
Full Sync is restricted to a single individual.