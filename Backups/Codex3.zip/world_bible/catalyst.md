# The Catalyst

Formerly remembered as a cataclysmic event.
The Maker caused the Catalyst to contain demonic incursion and seal the realms.