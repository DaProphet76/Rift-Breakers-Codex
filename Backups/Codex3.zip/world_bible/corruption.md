# Corruption

Misalignment with the Code weakens the soul.
A weakened soul becomes porous and vulnerable to demonic possession.

Accumulated possession increases pressure on reality.