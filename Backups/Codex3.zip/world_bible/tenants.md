# The Written Code

The Code was translated into written laws
so civilization could live in alignment.

These laws do not grant power, only preparation.