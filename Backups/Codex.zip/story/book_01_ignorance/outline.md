# Book 01 — Ignorance (Outline)

High-level beats for the era where society misunderstands the Cataclysm and dismisses the Tear.
