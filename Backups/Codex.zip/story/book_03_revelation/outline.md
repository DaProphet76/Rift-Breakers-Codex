# Book 03 — Revelation (Outline)

Truth surfaces: the Tear is named, the causal system is partially understood, and the path toward the Sundering is revealed.
