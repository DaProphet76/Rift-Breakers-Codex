# Protagonist (Dossier)

- Name:
- Background:
- Motivation:
- What they believe about the Cataclysm:
- What they eventually learn about the Tear:
