# Progression

Reality is moving toward a **future apocalyptic event** known in deep canon as **The Sundering**.

This must not be revealed in early story layers.
