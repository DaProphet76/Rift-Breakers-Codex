# Cosmology

High-level structure of existence (Ethereal, Spiritual, Physical) and how they relate.
