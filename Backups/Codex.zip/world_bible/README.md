# World Bible

Absolute canon. No POV. No narrative.
