# Causality Engine

Rules for how events in the Physical Realm echo into the Spiritual Realm, and how outcomes return as influence.
