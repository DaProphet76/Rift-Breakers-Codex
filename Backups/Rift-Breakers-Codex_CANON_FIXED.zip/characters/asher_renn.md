---
title: "Asher Renn"
type: "character"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

## Quick Identity
- **Full Name:** Asher Renn
- **Origin / District:** Outer Ring
- **Role in Story:** Supporting lead; narrative bridge to the true hero

## Appearance
Lean, work-worn, easily overlooked.

## Personality
Observant, steady, cautious.

## Background
Raised in the outer ring under constant surveillance.

## Arc
Observer → catalyst → ally.

## Canon Notes
- **Not the primary hero**
- Feels a persistent pull

## References
- chapter_01