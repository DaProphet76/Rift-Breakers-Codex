---
title: "Index"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# Book 01 — Ignorance

- [Chapter 00](chapter_00.md)
- [Chapter 01](chapter_01.md)
- [Chapter 02](chapter_02.md)