---
title: "Anomalies"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# Anomalies (Book 01)

This file tracks strange events that characters observe but cannot explain.

Template per anomaly:
- Date/Chapter:
- What happened (POV description):
- Why it is strange (from character view):
- Canon explanation link (world_bible file):