---
title: "Tenants"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# The Written Code

The Code was translated into written laws.
These laws guide civilization but do not grant power.