---
title: "Creature"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# <CREATURE/ENTITY NAME>

## Summary
<2–5 sentences.>

## Classification
- **Type:** <beast, spirit, construct, hybrid>
- **Realm of origin:** 

## Description
- <appearance and behavior>

## Intelligence and Communication
- <sentience level, language, signs>

## Abilities
- <ability>
- <ability>

## Weaknesses / Limitations
- <weakness>

## Ecology / Role in World
<Where it fits in the setting.>

## Encounters
- <known event/encounter>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>