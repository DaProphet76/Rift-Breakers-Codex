---
title: "Faction"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# <FACTION NAME>

## Summary
<2–5 sentences.>

## Identity
- **Symbols/insignia:** 
- **Core ideology:** 
- **Public face vs private truth:** 

## Structure
- **Leadership:** 
- **Ranks:** 
- **Recruitment:** 

## Resources
- **Territory:** 
- **Funding:** 
- **Artifacts/technology:** 

## Methods
- <how they operate>

## Allies and Enemies
- **Allies:** 
- **Enemies:** 

## Narrative Role
<Why this faction matters.>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>