---
title: "01 Base Frontmatter"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# <TITLE>

## Summary
<2–5 sentences. What this entry is, and why it matters.>

## Canon Notes
- **What is confirmed:** <bullet list>
- **What is intentionally unknown:** <bullet list>
- **Open questions:** <bullet list>

## References
- <Links to other Codex entries>