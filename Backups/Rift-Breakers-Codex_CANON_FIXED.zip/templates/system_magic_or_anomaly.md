---
title: "System Magic Or Anomaly"
type: "world_bible_entry"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- canon-review
- structured
---

# <SYSTEM / ANOMALY NAME>

## Summary
<2–5 sentences.>

## Scope
- **Applies to:** <who/where>
- **Observed by:** <who knows>

## Core Rules
1. <rule>
2. <rule>

## Inputs and Outputs
- **Inputs:** <costs, requirements>
- **Outputs:** <effects>

## Failure Modes
- <what goes wrong and why>

## Detection and Suppression
- <instruments fail? people react?>

## Known Instances
- <example>

## Narrative Purpose
<What this system enables in the plot.>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>