---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# The Catalyst (The Cataclyst)

When sin reached a critical threshold, the Maker caused a Tear.
A portion of the realm was removed, leaving a massive crater.
The Maker then withdrew from direct influence.