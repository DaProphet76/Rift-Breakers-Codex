---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# World Bible (Canon)

This folder contains **absolute truth** for the Rift-Breakers setting.

Rules:
- No POV
- No narrative prose
- No “maybe”
- If the story shows an event, it must be explainable by these files.

Recommended workflow:
1. Define rules here
2. Build characters (dossiers)
3. Write story that *reveals effects*, not the system
