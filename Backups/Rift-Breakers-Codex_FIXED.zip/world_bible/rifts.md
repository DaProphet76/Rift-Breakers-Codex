---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# Rifts

Rifts are micro-tears caused by accumulated sin.
If left unclosed, they allow population-level possession.
Rifts have not yet begun to form in the current age.