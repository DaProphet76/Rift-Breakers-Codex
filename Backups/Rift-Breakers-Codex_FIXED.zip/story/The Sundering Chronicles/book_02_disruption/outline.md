---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# Book 02 — Disruption (Outline)

Goal: the veil weakens. factions form around partial truths and counterfeit access.

Key beats (high level):
- chosen individuals emerge
- forced-access methods spread
- spiritual consequences intensify
