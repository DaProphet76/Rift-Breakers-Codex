---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# Antagonistic Forces (Dossier)

## Core Types
1. **Corrupted Practitioners**
   - attempt forced access without alignment
   - destabilize self and surroundings

2. **False Code Systems**
   - written imitations that promise power
   - produce corruption and control structures

3. **Spiritual Entities**
   - exploit the gap created by the Tear
   - influence human actors through pacts and deception

## Notes
- Specific factions/entities TBD
