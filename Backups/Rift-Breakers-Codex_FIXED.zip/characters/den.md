---
title: "Den"
type: "character"
status: "canon"
version: "1.0"
last_updated: "2025-12-28"
author: "Yoshua Israel"
source: "Codex"
related_entries:
- asher_renn
---

## Role
Supervisor representing institutional authority.
