---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# Protagonist (Dossier)

## Role
- “The One” (convergence point), first to regain access
- Begins cut off from True Code; can follow Written Code

## Starting State
- spiritually dormant
- high discipline potential
- guided by written law, not by power

## Arc (Non-Prose)
- awakens partial access
- unlocks abilities through growth
- never achieves total mastery of the Code
- leads other chosen toward alignment

## Notes
- Name TBD
- Origin TBD
