---
title: "REPLACE_ME"
type: "REPLACE_ME"
status: "draft"
version: "1.0"
last_updated: "2026-01-11"
author: "Yoshua Israel"
source: "Codex"
related_entries: []
tags:
- needs-review
- metadata
---

# Discarded Concepts (Non-Canon)

Store anything you want to keep without committing to canon.
Safe to contradict everything else.
