# The Cataclysm and the Tear

## Public Name: The Cataclysm
The widely taught historical label for the past apocalyptic event.

## True Name: The Tear
"The Tear" is the restricted, true name of the Cataclysm.
It is known only to certain individuals until later revelation.

## Important Distinction
The Tear/Cataclysm is **not** The Sundering.
