# Hidden Knowledge

Defines who can learn the term "The Tear", how they learn it, and why broader society dismisses or suppresses it.
