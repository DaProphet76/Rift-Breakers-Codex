# Realms

Defines the Ethereal (Maker's dwelling), Spiritual, and Physical realms, and how influence crosses boundaries.
