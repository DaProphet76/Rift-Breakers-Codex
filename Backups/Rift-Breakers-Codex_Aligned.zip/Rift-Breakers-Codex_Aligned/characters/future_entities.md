# Future Entities (Dossier)

Entities not yet on-stage in early books.
