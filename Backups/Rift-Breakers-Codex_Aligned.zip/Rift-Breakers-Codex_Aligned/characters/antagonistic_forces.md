# Antagonistic Forces (Dossier)

Define opposing factions/entities and their relationship to hidden knowledge.
