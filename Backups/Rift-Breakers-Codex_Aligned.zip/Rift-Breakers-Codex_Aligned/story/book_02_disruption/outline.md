# Book 02 — Disruption (Outline)

Escalation: anomalies intensify, factions form, hidden knowledge becomes actionable.
