# Anomalies

A list of strange events that hint at cross-realm causality without explaining canon directly.
