---
title: Discarded Concepts (Non-Canon)
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# Discarded Concepts (Non-Canon)

Store anything you want to keep without committing to canon.
Safe to contradict everything else.
