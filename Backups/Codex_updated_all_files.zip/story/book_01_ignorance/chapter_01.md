---
title: Chapter 01 (Draft Placeholder)
type: scene_chapter
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- scene_chapter
---

# <SCENE / CHAPTER TITLE>

## Purpose
<Why this scene exists (plot + character).>

## Viewpoint
- **POV character:** 
- **POV limitations:** <what they cannot know>

## Setting
- **Location:** 
- **Time:** 
- **Atmosphere:** 

## Scene Beats
1. <beat>
2. <beat>
3. <beat>

## Conflict
- **External:** 
- **Internal:** 

## Reveal / Information Drop
<What the reader learns.>

## Outcome
<What changes by the end of the scene.>

## Hooks
<What compels the next scene.>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>

## Existing Content

# Chapter 01 (Draft Placeholder)

Write in POV.
Do not explain canon rules directly.
Show effects and confusion.
