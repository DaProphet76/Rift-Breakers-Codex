---
title: Rifts
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# Rifts

Rifts form when sin accumulates in a region.
They are small tears in reality.

If left unclosed, rifts allow demonic forces to possess populations,
accelerating collapse.
