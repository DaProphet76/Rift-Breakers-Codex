---
title: Corruption
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# Corruption

Misalignment with the Code weakens the soul.
A weakened soul becomes porous and vulnerable to demonic possession.

Accumulated possession increases pressure on reality.
