---
title: The Catalyst
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# The Catalyst

Formerly remembered as a cataclysmic event.
The Maker caused the Catalyst to contain demonic incursion and seal the realms.
