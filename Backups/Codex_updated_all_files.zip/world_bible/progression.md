---
title: Progression
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# Progression

Access to the Code is restored gradually.
Growth, discipline, and alignment unlock latent abilities.
