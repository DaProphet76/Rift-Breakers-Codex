---
title: The Written Code
type: note
status: draft
version: '1.0'
last_updated: '2025-12-26'
author: Yoshua Israel
source: Codex
related_entries: []
tags:
- note
---

# The Written Code

The Code was translated into written laws
so civilization could live in alignment.

These laws do not grant power, only preparation.
