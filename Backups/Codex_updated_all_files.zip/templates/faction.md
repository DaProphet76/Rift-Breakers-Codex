---
title: "<FACTION NAME>"
type: "faction"
status: "draft"
version: "0.1"
last_updated: "2025-12-26"
author: "Yoshua Israel"
source: "Codex"
related_entries:
  - "characters/<CHARACTER>.md"
tags:
  - "faction"
  - "<ALIGNMENT>"
---

# <FACTION NAME>

## Summary
<2–5 sentences.>

## Identity
- **Symbols/insignia:** 
- **Core ideology:** 
- **Public face vs private truth:** 

## Structure
- **Leadership:** 
- **Ranks:** 
- **Recruitment:** 

## Resources
- **Territory:** 
- **Funding:** 
- **Artifacts/technology:** 

## Methods
- <how they operate>

## Allies and Enemies
- **Allies:** 
- **Enemies:** 

## Narrative Role
<Why this faction matters.>

## Canon Notes
- **Confirmed:** 
- **Intentionally unknown:** 
- **Open questions:**

## References
- <links>
