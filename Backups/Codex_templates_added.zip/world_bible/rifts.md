# Rifts

Rifts form when sin accumulates in a region.
They are small tears in reality.

If left unclosed, rifts allow demonic forces to possess populations,
accelerating collapse.