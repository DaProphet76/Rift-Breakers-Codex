# Cosmology

The Maker exists outside time and space.
Through the Code, all realms were created.

The Catalyst severed the realms to prevent total collapse caused by corruption,
possession, and uncontrolled rifts.