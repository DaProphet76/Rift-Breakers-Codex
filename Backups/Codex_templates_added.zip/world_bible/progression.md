# Progression

Access to the Code is restored gradually.
Growth, discipline, and alignment unlock latent abilities.